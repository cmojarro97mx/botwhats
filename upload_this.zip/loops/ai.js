
function replyByOpenAi(){
    return {success:false}
}

module.exports = { replyByOpenAi };
