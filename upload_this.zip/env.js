const appVersion = "6.1";
const addON = [""];

module.exports = { appVersion, addON };
